## Heading

# Java Arrays

## Creating an Array (Instantiation)

## Declaring an Array

# Heading 1

## Heading 2

### Heading 3

#### Heading 4

## Fin

## Heading
- world

# Java Arrays
- An **array** is a collection of variables of the same type

## Creating an Array (Instantiation)
- General form:  arrayName = new type[numberOfElements];
- numberOfElements must be a positive Integer.
- Gotcha: Array size is not modifiable once inst antiated.

## Declaring an Array
- General Form: type[] arrayName;
- only creates a reference
- no array has actually been created yet

# Heading 1
- important

## Heading 2
- this is kind of important
- this is also important
-  Fundies I is a prerequisite for Fundies II
-  Fundies II is a prerequisite for Object Oriented Design and Algorithms and Data Structures

### Heading 3

#### Heading 4
- i guess this is important
- this is also important
- and so is this

## Fin