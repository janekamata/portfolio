package cs3500.pa02.generatestudy;

/**
 * The interface mark down element represents an element in markdown.
 */
interface MarkdownElement {

}
